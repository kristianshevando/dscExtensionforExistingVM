﻿$sitename = "Default Web Site" 
xWebsite MainHTTPWebsite  
{  
    Ensure          = "Present"  
    Name            = $sitename
    ApplicationPool = "DefaultAppPool" 
    State           = "Started"  
    PhysicalPath    = "%SystemDrive%\inetpub\wwwroot"  
    BindingInfo     = @(
                        #@(MSFT_xWebBindingInformation   
                        #    {  
                        #        Protocol              = "HTTP"
                        #        Port                  =  80 
                        #        HostName              = "www.domain.tld"
                        #    }
                        #);
                        @(MSFT_xWebBindingInformation
                            {
                                Protocol              = "HTTP"
                                Port                  = 8080
                                HostName              = ""
                            }
                        )
                      )
    #DependsOn       = "[File]copyWebFiles"  
}